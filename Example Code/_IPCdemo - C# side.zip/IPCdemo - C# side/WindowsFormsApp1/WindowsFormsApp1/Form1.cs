﻿using NetMQ;
using NetMQ.Sockets;
using Newtonsoft.Json;
using Svg;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {}

        private void label2_Click(object sender, EventArgs e)
        {}

        private void textBox1_TextChanged(object sender, EventArgs e)
        {}

        private void label4_Click(object sender, EventArgs e)
        {}

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {}

        private void button1_Click(object sender, EventArgs e)
        {
            Console.WriteLine("Button clicked");
            DateTime startDatetime = dateTimePicker1.Value;
            string startStr = startDatetime.ToShortDateString();
            string nameStr = satName.Text;
            string hoursStr = hoursData.Text;
            string componentStr = componentTextBox.Text;

            string[] requestData = new string[4] { startStr, nameStr, hoursStr, componentStr };

            var requestJson = JsonConvert.SerializeObject(requestData);

            using (var client = new RequestSocket())
            {
                client.Connect("tcp://127.0.0.1:5555");
                client.SendFrame(requestJson);
                var msg = client.ReceiveFrameBytes();
                using (var stream = new MemoryStream(msg))
                {
                    //var svgDocument = SvgDocument.Open<SvgDocument>(stream);
                    //var bitmap = svgDocument.Draw();
                    var bitmap = Image.FromStream(stream);
                    pictureBox1.Image = bitmap;
                }
            }
        }
    }
}
